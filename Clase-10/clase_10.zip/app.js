/*let personajes = ["Rick Sanchez", "Morty Smith", "Beth Smith", "Summer Smith", "Jerry Smith"]
let smiths = 0
personajes.forEach(row => {
    if (row == "Rick Sanchez") console.log("No sumo nada")
    else smiths +=1
})


console.log(smiths)*/

/*
let numeros = [2,4,6]

let objs = [{nombre: "Lucas", apellido: "Cambon"}, {nombre: "Rocio", apellido: "Alvarez"}, {nombre: "Martin", apellido: "Castro"}]


let divido = numeros.map(row => row / 2)
//let divido = numeros.map((row, i) => i)

console.log(numeros)
console.log(divido)


let nombres = objs.map(row => row.nombre)

console.log(nombres)

*/

/*let productos = ["Pava electrica", "Mate", "Yerba", "Botinero", "Pelota"]


let edades = [24,21,20,22,30,46,58,10,17,19,3]

let mayores = edades.filter(row => row >= 24)
let menores = edades.filter(row => row <= 30)

console.log(mayores)
console.log(menores)



let busqueda = productos.filter(row => row.toLowerCase().includes("p"))
//let busqueda = productos.filter(row => row[0] == "P")
console.log(busqueda)


let objs = [{nombre: "Lucas", apellido: "Cambon"}, {nombre: "Rocio", apellido: "Alvarez"}, {nombre: "Martin", apellido: "Castro"}]


let filtro = objs.filter(row => row.nombre != "Lucas")
//let filtro = objs.filter(row => row.nombre.includes("a"))
//let filtro = objs.filter(row => row.nombre == "Lucas")
console.log(filtro)

*/

/*
let numeros = [2,4,6]

let objs = [{nombre: "Lucas", apellido: "Cambon", edad: 24}, {nombre: "Rocio", apellido: "Alvarez", edad: 34}, {nombre: "Martin", apellido: "Castro", edad: 47}]

let sumatoria = numeros.reduce((acum, currentValue) => acum + currentValue)

console.log(sumatoria)


let initialValue = 0

//let sumaEdades = objs.reduce((acum, currentValue) => acum + currentValue.edad, initialValue)
let sumaEdades = objs.reduce((acum, currentValue) => acum + currentValue.edad, 0)

console.log(sumaEdades)
*/

/*
let edades = [24,21,20,22,30,46,58,10,17,19,3]

let objs = [{nombre: "Lucas", apellido: "Cambon", edad: 24}, {nombre: "Rocio", apellido: "Alvarez", edad: 34}, {nombre: "Martin", apellido: "Castro", edad: 47}]


let encontrada = edades.find(row => row < 2)

let persona = objs.find(row => row.nombre == "Lucas")

console.log(encontrada)
console.log(persona)

*/

const traerDatos = require("./datosBici");

let datos = traerDatos("./bicicleta.json")

const dhBicis = {
    bicicletas: datos,
    buscarBici: function(id) {
        let biciBuscada = this.bicicletas.find(row => row.id == id)
        if (biciBuscada) return biciBuscada
        else return null
    },
    venderBici: function(id) {
        let biciBuscada = this.buscarBici(id)

        if(biciBuscada == null) return "Bicicleta no encontrada."
        else biciBuscada.vendida = true
    },
    biciParaLaVenta: function() {
        let bicisALaVenta = this.bicicletas.filter(row => row.vendida == false)
        return bicisALaVenta
    },
    totalDeVentas: function() {
        let bicisVendidas = this.bicicletas.filter(row => row.vendida == true)

        let total = 0

        let ventasTotales = bicisVendidas.reduce((acum, currentValue) => acum + currentValue.precio, total)

        return ventasTotales
    }
}

//console.log(dhBicis.buscarBici(100000000000000))

//dhBicis.venderBici(1)
//console.log(dhBicis.venderBici(100000000000000))
//console.log(dhBicis.bicicletas)

//console.log(dhBicis.biciParaLaVenta())

//console.log(dhBicis.totalDeVentas())