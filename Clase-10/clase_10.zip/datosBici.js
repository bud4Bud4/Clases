const fs = require("fs");

function traerDatos(ruta) {

    let archivoJSON = fs.readFileSync(ruta, "utf-8")

    let datos = JSON.parse(archivoJSON)

    return datos
};


module.exports = traerDatos;